﻿namespace WebAPIBase.Model
{
    public class AppSettings
    {
        public string MySqlConnectionString { get; set; }
    }
}