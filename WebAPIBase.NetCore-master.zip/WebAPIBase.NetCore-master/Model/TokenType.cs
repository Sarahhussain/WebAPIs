﻿namespace WebAPIBase.Model
{
    public enum TokenType
    {
        Facebook = 1,
        Google = 2,
        Microsoft = 3
    }
}